<template>
  <div id="app">
    <router-view/>
    <span style="font-family:siyu-normal;"></span>
    <span style="font-family:siyu-bold;"></span>
  </div>
</template>

<script>

export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 30px;
  margin-bottom:30px;
} 
@font-face {  
    font-family: "siyu-bold";  
    src:url("/static/siyu-bold.otf");  
}   
@font-face {  
    font-family: "siyu-normal";  
    src:url("/static/siyu-normal.otf");  
}
</style>
