<template>
  <div id="home" class="hello">
       <Form ref="formInline" :model="form"  :label-width="130">
        <FormItem label="链接："  >
          <Input v-model="form.links" class="text"/>
        </FormItem>
        <FormItem label="贴纸样式：" >
          <uploading @upload="uploadImg" :amount="1" selectfiles="pic" ref="pic"></uploading>
        </FormItem>
<!-- ------------------------------------------------------------------------ -->
        <FormItem class="title" label="标题-文案："  >
          <Input v-model="form.title" class="text"/>
        </FormItem>
        <FormItem label="标题-字体："  >
          <Select class="select" v-model="form.titlefamily">
            <Option v-for="item in fontfamily" :value="item.name" :key="item.name">{{ item.name }}</Option>
          </Select>
        </FormItem>
        <FormItem label="标题-字体大小："  >
           <Input v-model="form.titlesize" class="select"/>
        </FormItem>
        <FormItem label="标题-字体颜色："  >
          <ColorPicker class="select" v-model="form.titlecolor" />
        </FormItem>
        <FormItem label="标题-位置："  >
          X：<Input placeholder="x" v-model="form.titlepositionX" style="width:100px;" class="text"/> ，
          Y：<Input placeholder="y" v-model="form.titlepositionY" style="width:100px;" class="text"/>
        </FormItem>
        <FormItem label="标题-图片："  >
          <uploading @upload="uploadtitleImg" :amount="1" selectfiles="picss" ref="picss"></uploading>
        </FormItem>
<!-- ------------------------------------------------------------------------ -->
        <FormItem class="title" label="详情-文案："  >
          <Input v-model="form.detail" class="text"/>
        </FormItem>
        <FormItem label="详情-字体："  >
          <Select class="select" v-model="form.detailfamily">
            <Option v-for="item in fontfamily" :value="item.name" :key="item.name">{{ item.name }}</Option>
          </Select>
        </FormItem>
        <FormItem label="详情-字体大小："  >
          <Input v-model="form.detailsize" class="select"/>
        </FormItem>
        <FormItem label="详情-字体颜色："  >
          <ColorPicker class="select" v-model="form.detailcolor" />
        </FormItem>
        <FormItem label="详情-位置："  >
          X：<Input placeholder="x" v-model="form.detailpositionX" style="width:100px;" class="text"/> ，
          Y：<Input placeholder="y" v-model="form.detailpositionY" style="width:100px;" class="text"/>
        </FormItem>
        <FormItem label="详情-图片："  >
          <uploading @upload="uploadDetailImg" :amount="1" selectfiles="pics" ref="pics"></uploading>
        </FormItem>
<!-- ------------------------------------------------------------------------ -->
        <FormItem class="title" label="编号-字体："  >
          <Select class="select" v-model="form.numfamily">
            <Option v-for="item in fontfamily" :value="item.name" :key="item.name">{{ item.name }}</Option>
          </Select>
        </FormItem>
        <FormItem label="编号-字体大小："  >
          <Input v-model="form.numsize" class="select"/>
        </FormItem>
        <FormItem label="编号-字体颜色："  >
          <ColorPicker class="select" v-model="form.numcolor" />
        </FormItem>
        <FormItem label="编号-位置："  >
          X：<Input placeholder="x" v-model="form.numpositionX" style="width:100px;" class="text"/> ，
          Y：<Input placeholder="y" v-model="form.numpositionY" style="width:100px;" class="text"/>
        </FormItem>
        <FormItem label="生成图片"  >
          <RadioGroup v-model="disabledGroup">
            <Radio label="2">多张</Radio>
            <Radio label="1">一张</Radio>
        </RadioGroup>
        </FormItem>
        <FormItem v-if="disabledGroup == '1'" label="设备编号(单个)："  >
          <Input v-model="form.device_name" class="text"/>
        </FormItem>
        <FormItem v-if="disabledGroup == '2'" label="设备编号(多个)："  >
          <Input placeholder="字母" style="width:50px;" v-model="form.device_word" class="text"/>
          <Input v-model="form.device_name1" style="width:100px;" class="text"/> ~ 
          <Input v-model="form.device_name2" style="width:100px;" class="text"/>
        </FormItem>

<!-- ------------------------------------------------------------------------ -->
        <FormItem label="二维码-大小："  >
          宽：<Input placeholder="宽" v-model="form.codeWidth" style="width:100px;" class="text"/> ，
          高：<Input placeholder="高" v-model="form.codeHeight" style="width:100px;" class="text"/>
        </FormItem>
        <FormItem label="二维码-位置："  >
          X ：<Input placeholder="x" v-model="form.codepositionX" style="width:100px;" class="text"/> ，
          Y ：<Input placeholder="y" v-model="form.codepositionY" style="width:100px;" class="text"/>
        </FormItem>
<!-- ------------------------------------------------------------------------ -->
    </Form>
    <div class="submit">
      <Button class="submitBtn" long @click="submit">点击生成图片</Button>
      <Button class="submitBtn" long @click="look">预览</Button>
    </div>
    <div class="work">
      <div class="qrcode-box" id="qrcode" ref="qrcode"></div>
      <img crossOrigin="anonymous" :src="form.img" id="codeBg" ref="codeBg" alt="">
      <img crossOrigin="anonymous" :src="form.detailImg"  id="detailImg" ref="detailImg" alt="">
      <img crossOrigin="anonymous" :src="form.titleImg"  id="titleImg" ref="titleImg" alt="">
      <canvas id="MyCanvas"></canvas>
    </div>
    <img crossOrigin="anonymous" style="width: auto;height:220px; margin-left:8%;" :src="lookIMG" alt="">
  </div>
</template>
<script>
import QRCode from "qrcodejs2";
import Uploading from './upload/uploading.vue'
export default {
  name: 'home',
  components: {Uploading},
  data () {
    return {
      lookIMG:'',
      disabledGroup:'2',
      device:'',
      deviceList:[],
      fontfamily:[{name:'siyu-bold'},{name:'siyu-normal'}],
      form:{
        img:'',
        titleImg:'',
        detailImg:'',
        codeWidth:468,
        codeHeight:468,
        codepositionX:2990,
        codepositionY:235,
        codenum:[],
        device_word:'',
        device_name1:'',
        device_name2:'',
        links:'',
        device_name:'',
        titlecolor:'#fff',
        detailcolor:'#fff',
        titlepositionX:340,
        titlepositionY:368,
        detailpositionX:388,
        detailpositionY:684,
        numpositionX:2216,
        numpositionY:478,
        numcolor:'#fff',
        titlesize:210,
        detailsize:50,
        numsize:280,
        link:[],
        titlefamily:'siyu-bold',
        detailfamily:'siyu-normal',
        numfamily:'siyu-bold',
      },
      ruleInline:[]
    }
  },
  methods:{
    uploadDetailImg(files){
      this.form.detailImg = files[0]
    },
    uploadImg(files){
      this.form.img = files[0]
    },
    uploadtitleImg(files){
      this.form.titleImg = files[0]
    },
    submit(){
      if(!this.form.img){
        this.$Message.info('请上传图片');
        return
      }
      if(!this.form.links){
        this.$Message.info('请填写地址');
        return
      }
      if (this.disabledGroup == '2') {
        for (let i = this.form.device_name1*1;i<=this.form.device_name2*1;i++){ 
          this.form.link.push(this.form.links + '?device_name='+this.form.device_word+i)
          this.form.codenum.push(i)
        }
      }else{
        this.form.link.push(this.form.links + '?device_name='+this.form.device_name)
        this.form.codenum.push(this.form.device_name)
      }
      this.$router.push({name:'code',query:this.form})
    },
    look(){
      if(!this.form.img){
        this.$Message.info('请上传图片');
        return
      }
      if(!this.form.links){
        this.$Message.info('请填写地址');
        return
      }
      let form = this.form
      let link = ''
      let text = ''
      let code1 = document.getElementById('qrcode').getElementsByTagName('img')[0];
      let code2 = document.getElementById('qrcode')
      if(code1){
        code2.innerHTML = "";
      }
      if(this.disabledGroup == '2'){
        link = form.links + '?device_name=' + form.device_word + form.device_name1
        text = form.device_word + form.device_name1
      }else{
        link = form.links + '?device_name=' + form.device_name
        text = form.device_name
      }
      let qrcode_ = new QRCode("qrcode", {
          width: form.codeWidth, // 二维码宽度，单位像素
          height: form.codeHeight,// 二维码高度，单位像素
          text: form.links+form.device_word +'?device_name='+ form.device_name1||form.device_name // 设置二维码内容或跳转地址
      });
      let canvas = document.getElementById('MyCanvas');
      let home = document.getElementById('home');
      let code = document.getElementById('qrcode').getElementsByTagName('img')[0];
      let codeBg = this.$refs.codeBg;
      let detailImg = this.$refs.detailImg;
      let titleImg = this.$refs.titleImg;
      code.onload = ()=>{
        let maxW = codeBg.offsetWidth;
        let maxH = codeBg.offsetHeight;
        canvas.width = maxW;
        canvas.height = maxH;
        this.form.imgBG = form.img
        let context = canvas.getContext('2d');
        context.drawImage(codeBg, 0, 0, maxW, maxH);
        // 标题文字 pic
        if(form.titleImg){
          context.drawImage(titleImg, form.titlepositionX,form.titlepositionY);
        }else{
          context.font=form.titlesize+'px '+form.titlefamily;
          context.fillStyle = form.titlecolor;
          context.fillText(form.title||'',form.titlepositionX,form.titlepositionY);
        }
        function writeTextOnCanvas(ctx_2d, lineheight, bytelength, text ,startleft, starttop){
          function getTrueLength(str){//获取字符串的真实长度（字节长度）
            var len = str.length, truelen = 0;
            for(var x = 0; x < len; x++){
              if(str.charCodeAt(x) > 128){
                truelen += 2;
              }else{
                truelen += 1;
              }
            }
            return truelen;
          }
          function cutString(str, leng){//按字节长度截取字符串，返回substr截取位置
            var len = str.length, tlen = len, nlen = 0;
            for(var x = 0; x < len; x++){
              if(str.charCodeAt(x) > 128){
                if(nlen + 2 < leng){
                  nlen += 2;
                }else{
                  tlen = x;
                  break;
                }
              }else{
                if(nlen + 1 < leng){
                  nlen += 1;
                }else{
                  tlen = x;
                  break;
                }
              }
            }
            return tlen;
          }
          for(var i = 1; getTrueLength(text) > 0; i++){
            var tl = cutString(text, bytelength);
            ctx_2d.fillText(text.substr(0, tl).replace(/^\s+|\s+$/, ""), startleft, (i-1) * lineheight + starttop);
            text = text.substr(tl);
          } 
        }    
        //详情文字及图片
        if(form.detailImg){
          context.drawImage(detailImg, form.detailpositionX,form.detailpositionY);
        } else{
          context.fillStyle = form.detailcolor;
          context.font=form.detailsize+'px '+form.detailfamily;
          writeTextOnCanvas(context,60,46,form.detail||'',form.detailpositionX,form.detailpositionY)
        }      
        //绘制编号
        context.font=form.numsize+'px '+form.numfamily;
        context.fillStyle = form.numcolor;
        context.textAlign = "center";
        context.textBaseline = "middle";
        context.fillText(text||'',form.numpositionX,form.numpositionY);
        //绘制二维码
        context.drawImage(code, form.codepositionX,form.codepositionY,form.codeWidth,form.codeHeight);
        this.lookIMG = canvas.toDataURL('image/jpg')
      }
    }
  }
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="stylus">
@import '../assets/common.styl';
@import '../assets/public.styl';
.ivu-form-item{
  padding-left:15%;
  margin:rem(4);  
}
.text{
  width:rem(160);  
} 
.title{
  border-top:2px solid #eee;  
  padding-top:24px;
}
.select{
  width:320px;  
}
.submit{
  width:50%;
  margin-left:15%;
  flex-ajd()
  .submitBtn{
    margin:10px 0;
    border-radius:rem(6);  
  }
}
.work{
  position:fixed;  
  top:999999999999999999999;
  left:99999999999999999999;
  opacity :0;
}
</style>
