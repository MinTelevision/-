<template>
  <div class="uploader">
    <div class="cho">
      <div v-if="show">
        <Button :id="selectfiles">
          选择文件
        </Button>
      </div>
    </div>
    <div class="demo-upload-list" v-for="(item,index) in pic_list" :key="index">
      <template>
        <img :src="item">
      </template>
    </div>
  </div>
</template>
<script>
let files = []
// import md5 from 'js-md5'
export default {
  name: 'uploader',
  data: function () {
    return {
      pic_list: [],
      visible: false,
      imgName: ''
    }
  },
  props: {
    amount: {
      type: Number,
      default: 1
    },
    imgs: {},
    selectfiles: {
      type: String,
      default: 'selectfiles'
    },
    banner: {},
    show: {
      type: Boolean,
      default: true
    }
  },
  methods: {
    sendTOAliYunOss () {
      // 更改图片的元件
      var accessid = 'LTAIYbi4miG78ek7'
      // var accesskey = 'i6N02yHqBtD7bD1SqN2E4oL4HO7GBn'
      var host = 'https://upay-upload.oss-cn-shenzhen.aliyuncs.com/'
      var policyBase64 = 'eyJleHBpcmF0aW9uIjoiMjAyMC0wMS0wMVQxMjowMDowMC4wMDBaIiwiY29uZGl0aW9ucyI6W1siY29udGVudC1sZW5ndGgtcmFuZ2UiLDAsMTA0ODU3NjAwMF1dfQ=='
      var signature = 'IDK2QL0slvaU3dE5yb8XtO2KRXc='
      var key = 'live/' + (new Date() / 1000) + '${filename}'
      var filename = 'live/' + (new Date() / 1000)
      // filename = md5(filename)
      var uploader = new plupload.Uploader({
        url: host,
        browse_button: this.selectfiles,
        rename: true,
        unique_names: true,
        multipart_params: {
          Filename: `${filename}`,
          key: key,
          policy: policyBase64,
          OSSAccessKeyId: accessid,
          success_action_status: '200', // 让服务端返回200,不然，默认会返回204
          signature: signature
        },
        resize:{
          quality: 80,
          preserve_headers: false
        },
        filters: {
          mime_types: [
            // 只允许上传图片
            {
              title: 'Image files',
              extensions: 'jpeg,jpg,gif,png'
            }
          ]
        }
      })
      uploader.init()
      uploader.bind('PostInit', function () {})
      uploader.bind('FileFiltered', function (up, file) {})
      var that = this
      uploader.bind('Error', function (up, err) {
        if (err.code === -600) {
          that.$Notice.warning({
            title: '温馨提示',
            desc: '您上传的图片尺寸过大,请重新选择上传'
          })
        }
      })
      // 绑定文件上传进度事件
      uploader.bind('UploadProgress', function (uploader, file) {
        that.uploadShow = true
        that.percent2 = file.percent
      })
      uploader.bind('FileUploaded', function (up, file, info) {
        if (info.status === 200) {
          setTimeout(function () {
            that.uploadShow = false
            that.percent2 = 0
            if (that.pic_list.length === 0) {
              files = []
            }
            if (that.amount === 1) {
              that.pic_list = []
            } else {
              files.push(host + file.name)
              if (that.pic_list.length > that.amount) {
                that.$Notice.warning({
                  title: '温馨提示',
                  desc: '最多只能上传' + that.amount + '张图片'
                })
                return
              }
            }
            that.pic_list.push(host + filename + file.name)

            // console.log(that.pic_list)
            that.$emit('upload', that.pic_list, that.amount, that.selectfiles)
              let OSS = require('ali-oss');
              let client = new OSS({
                region: 'oss-cn-shenzhen',
                accessKeyId: 'LTAI4Fg5g2gnG9GZ2tFHJVxo',
                accessKeySecret:'bM9XqcjUoSfW3EPC6VawQfHMxwbpac',
                bucket: 'upay-upload'
              });
            client.copy(filename + file.name, filename + file.name, {headers:{'Cache-Control':'max-age=86400'}});
            }, 1)
        } else {
          that.$Message.error('上传失败')
        }
      })
      uploader.bind('BeforeUpload', (uploader, file) => {})
      uploader.bind('FilesAdded', function (up, files) {
        uploader.start()
      })
    },
    handleView (index) {
      this.visible = true
      this.imgName = this.pic_list[index]
    },
    handleRemove (index) {
      this.$Modal.confirm({
        title: '提示',
        content: '确定删除',
        onOk: () => {
          this.pic_list.splice(index, 1)
          this.$emit('remove', this.pic_list, this.amount, this.selectfiles, index)
        },
        onCancel: () => {
          this.$Message.info('点击了取消')
        }
      })
    },
    empty () {
      this.pic_list = this.banner
      this.pic_list = []
    },
    getOncepic (pic) {
      this.pic_list = []
      this.pic_list.push(pic)
       if(pic=='0'){
        this.pic_list = []
      }
    },
    getManyPic (pic) {
      this.pic_list = pic
    }
  },
  created () {
    this.$nextTick(() => {
      this.sendTOAliYunOss()
    })
  }
}

</script>
<style lang="stylus">
@import '../../assets/common.styl';
@import '../../assets/public.styl';
.demo-upload-list {
  display: inline-block;
  overflow: hidden;
  margin-top:20px;
}
.demo-upload-list img {
  height: 100px;
}
.cho{
  // margin-bottom:rem(4);  
}
</style>
