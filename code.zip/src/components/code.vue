<template>
    <!--弹出框-->
	<div ref="popupCenter" id="popupCenter" class="popupCenter">
    <!-- <img style="width: 5316px;height:945px;margin-top:120px;" v-if="!show" :src="imgs" alt=""> -->
      <div class="buttons">
        <Button :loading="loading" :disabled="btnshow" class="btn" type="info"   long  @click="downLoad">
           <span v-if="!loading">下载</span>
            <span v-else>下载组件加载中..请稍后</span>
        </Button>
        <Button :disabled="btnshow" class="btn" type="success"  long @click="showPIC">显示图片</Button>
      </div>
    <div v-if="show" style="opacity:0;overflow:hidden;">
      <div class="saveImgs">
        <img crossOrigin="anonymous" :src="list.img"  id="codeBg" ref="codeBg" alt="">
        <img crossOrigin="anonymous" :src="list.detailImg"  id="detailImg" ref="detailImg" alt="">
        <img crossOrigin="anonymous" :src="list.titleImg"  id="titleImg" ref="titleImg" alt="">
        <div v-for="(item,index) in list.link" :key="index" class="qrcode-box" :id='"qrcode" + index' ref="qrcode"></div>
	    </div>
    <canvas v-for="(item,index) in list.link" :key="index" :id="'MyCanvas'+index"></canvas>
    </div>
	</div>
</template>
<script>
import QRCode from "qrcodejs2";
import FileSaver from 'file-saver';
import JSZip from 'JSZip';
export default {
  data () {
    return {
      loading:false,
      btnshow:true,
      canvasList:[],
      havePic:0,
      imgs:'',
      show:true,
      list:{},
      codes:'',
    }
  },
  methods:{
    downLoad(){
      var that = this
      this.loading = true
      let canvasList = this.canvasList
      var zip = new JSZip();
      var file_name = '';
      canvasList.forEach((item,index) => {
        var img = zip.folder("images");
        var img_arr = item.split(',');
        img.file(this.list.device_word + this.list.codenum[index]+'海报.jpg',img_arr[1],{base64: true});
      });
      zip.generateAsync({type:"blob"}).then(function(content) {
          saveAs(content, "images.zip");
          that.loading = false
      });
    },
    qrcode(){
      console.log('1',typeof(this.list.link));
      if (typeof(this.list.link) == 'string') {
        let qrcode = new QRCode("qrcode"+'0', {
            width: this.list.codeWidth, // 二维码宽度，单位像素
            height: this.list.codeHeight,// 二维码高度，单位像素
            text: this.list.link // 设置二维码内容或跳转地址
        });
      }else{
        this.list.link.forEach((item,index) => {
        let qrcode = new QRCode("qrcode"+index, {
            width: this.list.codeWidth, // 二维码宽度，单位像素
            height: this.list.codeHeight,// 二维码高度，单位像素
            text: item // 设置二维码内容或跳转地址
          });
        });
      }
    },
    reload(){
      location.reload();
    },
    showPIC(){
      this.canvasList.forEach((item,index) => {
        let img = new Image();
        img.src = item
        img.style.width = '100%'
        img.setAttribute('crossOrigin', 'anonymous')
        img.style.height = 'auto'
        popupCenter.appendChild(img);
      });
    }
  },
  mounted(){
    this.$Message.loading({
        content: '正在生成图片...',
        duration: 0,
        closable: false,
    });
    var array = []
    this.list = this.$route.query
    let list = this.list
    this.$nextTick(() => {
      this.qrcode();
      let codeBg = this.$refs.codeBg;
      let qrcode = this.$refs.qrcode;
      let detailImg = this.$refs.detailImg;
      let titleImg = this.$refs.titleImg;
      var that = this
      codeBg.onload = function(){
        setTimeout(() => {
          let maxW = codeBg.offsetWidth;
          let maxH = codeBg.offsetHeight;
          that.show = false
          for(let i = 0;i<that.list.link.length;i++){
              let canvas = document.getElementById('MyCanvas'+i);
              let popupCenter = document.getElementById('popupCenter');
              canvas.width = maxW;
              canvas.height = maxH;
              let context = canvas.getContext('2d');
              let code = document.getElementById('qrcode'+i).getElementsByTagName('img')[0];
              context.drawImage(codeBg, 0, 0, maxW, maxH);
              // context.scale(2,2)
              //标题文字
              if(list.titleImg){
                context.drawImage(titleImg, list.titlepositionX,list.titlepositionY);
              }else{
                context.font=list.titlesize+'px '+list.titlefamily;
                context.fillStyle = list.titlecolor;
                context.fillText(list.title||'',list.titlepositionX,list.titlepositionY);
              }
              //详情文字
              function writeTextOnCanvas(ctx_2d, lineheight, bytelength, text ,startleft, starttop){
                function getTrueLength(str){//获取字符串的真实长度（字节长度）
                  var len = str.length, truelen = 0;
                  for(var x = 0; x < len; x++){
                    if(str.charCodeAt(x) > 128){
                      truelen += 2;
                    }else{
                      truelen += 1;
                    }
                  }
                  return truelen;
                }
                function cutString(str, leng){//按字节长度截取字符串，返回substr截取位置
                  var len = str.length, tlen = len, nlen = 0;
                  for(var x = 0; x < len; x++){
                    if(str.charCodeAt(x) > 128){
                      if(nlen + 2 < leng){
                        nlen += 2;
                      }else{
                        tlen = x;
                        break;
                      }
                    }else{
                      if(nlen + 1 < leng){
                        nlen += 1;
                      }else{
                        tlen = x;
                        break;
                      }
                    }
                  }
                  return tlen;
                }
                for(var i = 1; getTrueLength(text) > 0; i++){
                  var tl = cutString(text, bytelength);
                  ctx_2d.fillText(text.substr(0, tl).replace(/^\s+|\s+$/, ""), startleft, (i-1) * lineheight + starttop);
                  text = text.substr(tl);
                } 
              } 
              if(list.detailImg){
                context.drawImage(detailImg, list.detailpositionX,list.detailpositionY);
              }else{
                context.font=list.detailsize+'px '+list.detailfamily;
                writeTextOnCanvas(context,60,46,list.detail||'',list.detailpositionX,list.detailpositionY)
              }
              context.font=list.numsize+'px '+list.numfamily;
              context.fillStyle = list.numcolor;
              //绘制编号
              context.textAlign = "center";
              context.textBaseline = "middle";
              context.fillText(that.list.device_word+that.list.codenum[i]||'',list.numpositionX,list.numpositionY);
              //绘制二维码
              context.drawImage(code, list.codepositionX,list.codepositionY,list.codeWidth,list.codeHeight);
              that.canvasList.push(canvas.toDataURL('image/jpg'))
              // 显示图片
              // let img = new Image();
              // img.src = canvas.toDataURL('image/jpg');
              // img.style.width = '100%'
              // img.setAttribute('crossOrigin', 'anonymous')
              // img.style.height = 'auto'
              // popupCenter.appendChild(img);
              that.$Message.destroy();
              that.$Message.success('图片生成成功');
              that.btnshow = false
            }
          }, 1000);
        }
    })
  },
  watch: {

  },
}
</script>
<style scoped lang="stylus">
@import '../assets/common.styl';
@import '../assets/public.styl';
.buttons{
  padding:0 1%;
  width:100%;
  position:fixed
  bottom:1px;
  flex-ajd()  
  text-align center
  .btn{
    width:70%;  
    border-radius:10px;
    margin-bottom 20px;
  }
  // padding:0 20px;
  // margin-bottom :10px;
}
</style>
